# OS X

A Pen created on CodePen.

Original URL: [https://codepen.io/jackharner/pen/jPmKGe](https://codepen.io/jackharner/pen/jPmKGe).

A recreation of the Mac OS X desktop including drop down menus, selectable desktop icons and more!

Works pretty much only in Chrome. Codepen preview makes it a little wonky.